if (localStorage.getItem("token") == null) {
    alert("Voce precisa estar logado para acessar essa pagina")
    window.location.href = "/assets/html/login.html"
}

let userLogado = JSON.parse(localStorage.getItem("userLogado"))

let logado = document.querySelector("#logado")
logado.innerHTML = `Ola ${userLogado.nome}`

function sair() {
    localStorage.removeItem("token")
    localStorage.removeItem("userLogado")
    window.location.href = "/assets/html/login.html"
}