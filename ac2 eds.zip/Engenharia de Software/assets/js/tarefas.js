document.addEventListener("DOMContentLoaded", function() {
    var dataAtual = new Date(); // Obtém a data atual do dispositivo

    var titulo = document.createElement('h2');
    titulo.textContent = 'Tarefas para o dia ' + dataAtual.toLocaleDateString('pt-BR');
    document.body.appendChild(titulo);

    // Define o conteúdo do elemento 'dataTarefa' como a data atual do dispositivo
    document.getElementById('dataTarefa').textContent = dataAtual.toLocaleDateString('pt-BR');

    exibirTarefas();
});


function exibirTarefas() {
    var listaTarefas = document.getElementById('listaTarefas');
    listaTarefas.innerHTML = ''; 

    var tarefas = obterTarefas();
    
    tarefas.forEach(function(tarefa, index) {
        var itemLista = document.createElement('li');
        itemLista.textContent = tarefa;

        var btnExcluir = document.createElement('button');
        btnExcluir.textContent = 'Excluir';
        btnExcluir.classList.add('excluir-tarefa');
        btnExcluir.dataset.index = index; // Armazena o índice da tarefa no dataset

        btnExcluir.addEventListener('click', function() {
            var index = parseInt(this.dataset.index);
            excluirTarefa(index);
        });

        itemLista.appendChild(btnExcluir);
        listaTarefas.appendChild(itemLista);

        
    });
}

function excluirTarefa(index) {
    var tarefas = obterTarefas();
    tarefas.splice(index, 1); // Remove a tarefa com o índice especificado
    salvarTarefas(tarefas);
    exibirTarefas(); // Atualiza a lista de tarefas exibidas
}

function obterTarefas() {
    var dataParam = new URLSearchParams(window.location.search).get('data');
    var dataString = new Date(dataParam).toLocaleDateString('pt-BR');
    var tarefas = localStorage.getItem(dataString);

    return tarefas ? JSON.parse(tarefas) : [];
}

document.getElementById('formularioTarefa').addEventListener('submit', function(event) {
    event.preventDefault(); 

    var inputTarefa = document.getElementById('inputTarefa');
    var novaTarefa = inputTarefa.value.trim(); 

    if (novaTarefa !== '') {
        var tarefas = obterTarefas();
        tarefas.push(novaTarefa);
        salvarTarefas(tarefas);

        inputTarefa.value = '';
        exibirTarefas();
    }
});

function salvarTarefas(tarefas) {
    var dataParam = new URLSearchParams(window.location.search).get('data');
    var dataString = new Date(dataParam).toLocaleDateString('pt-BR');

    localStorage.setItem(dataString, JSON.stringify(tarefas));
}
