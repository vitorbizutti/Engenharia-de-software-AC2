document.addEventListener("DOMContentLoaded", function() {
    criarCalendario("calendario1", 0); 
    criarCalendario("calendario2", 1); 
    criarCalendario("calendario3", 2); 
    criarCalendario("calendario4", 3); 

    document.getElementById('avancar').addEventListener('click', avancarCalendarios);
    document.getElementById('retroceder').addEventListener('click', retrocederCalendarios);
});

var offsets = [0, 1, 2, 3];

function avancarCalendarios() {
    for (var i = 0; i < offsets.length; i++) {
        offsets[i] += 4;
        criarCalendario("calendario" + (i + 1), offsets[i]);
    }
}

function retrocederCalendarios() {
    for (var i = 0; i < offsets.length; i++) {
        offsets[i] -= 4;
        criarCalendario("calendario" + (i + 1), offsets[i]);
    }
}


function criarCalendario(elementId, offset) {
    var dataAtual = new Date();
    var ano = dataAtual.getFullYear() + Math.floor(offset / 12); 
    var mes = (dataAtual.getMonth() + offset) % 12; 

    var diasNoMes = new Date(ano, mes + 1, 0).getDate();
    var primeiroDiaSemana = new Date(ano, mes, 1).getDay();
    var meses = [
        "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
    ];

    var classeMesAtual = "";
    if (offset === 0) {
        classeMesAtual = " mes-atual"; 
    }

    var tabela = '<h2 class="' + classeMesAtual + '">' + meses[mes] + ' ' + ano + '</h2>';
    tabela += '<table>';
    tabela += '<tr><th class="dia-semana">Dom</th><th class="dia-semana">Seg</th><th class="dia-semana">Ter</th><th class="dia-semana">Qua</th><th class="dia-semana">Qui</th><th class="dia-semana">Sex</th><th class="dia-semana">Sáb</th></tr>';
    tabela += '<tr>';

    var dia = 1;
    var diaMesAnterior = new Date(ano, mes, 0).getDate() - primeiroDiaSemana + 1;

    for (var i = 0; i < 42; i++) {
        if (i < primeiroDiaSemana) {
            tabela += '<td class="mes-anterior dia-mes">' + diaMesAnterior + '</td>';
            diaMesAnterior++;
        } else if (dia <= diasNoMes) {
            var classe = "dia-mes";
            if (dia === dataAtual.getDate() && mes === dataAtual.getMonth() && ano === dataAtual.getFullYear()) {
                classe += " dia-atual";
            }
            tabela += '<td class="' + classe + '" id="' + elementId + '-dia-' + dia + '">' + dia + '</td>';
            dia++;
        } else {
            tabela += '<td class="mes-proximo dia-mes">' + (dia - diasNoMes) + '</td>';
            dia++;
        }

        if ((i + 1) % 7 === 0) {
            tabela += '</tr>';
            if (dia > diasNoMes) break;
            tabela += '<tr>';
        }
    }

    tabela += '</table>';
    document.getElementById(elementId).innerHTML = tabela;

    var diasDoMes = document.querySelectorAll('#' + elementId + ' .dia-mes');
    diasDoMes.forEach(function(dia) {
        dia.addEventListener('click', function() {
            var numeroDia = parseInt(this.innerText);
            var url = 'Tarefas.html?data=' + encodeURIComponent(ano + '-' + (mes + 1) + '-' + numeroDia);
            window.location.href = url;
        });
    });
}

