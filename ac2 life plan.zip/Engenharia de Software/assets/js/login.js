// signup


let btn = document.querySelector('#verSenha')
let btnConfirm = document.querySelector('#verConfirmaSenha')


let nome = document.querySelector('#nome')
let labelNome = document.querySelector('#labelNome')
let validNome = false

let email = document.querySelector('#email')
let labelEmail = document.querySelector('#labelEmail')
let validEmail = true

let cpf = document.querySelector('#CPF')
let labelCpf = document.querySelector('#labelCPF')
let validCpf = false

let senha = document.querySelector('#senha')
let labelSenha = document.querySelector('#labelSenha')
let validSenha = false

let confirmaSenha = document.querySelector('#confirmaSenha')
let labelConfirmaSenha = document.querySelector('#labelConfirmaSenha')
let validConfirmaSenha = false

let msgError = document.querySelector('#msgError')
let msgSuccess = document.querySelector('#msgSuccess')

nome.addEventListener('keyup', () => {
  if(nome.value.length <= 2){
    validNome = false
  } else {
    validNome = true
  }
})


email.addEventListener('keyup', () => {
    /*
    var u = email.value.substring(0, email.value.indexOf("@"));
    var d = email.value.substring(email.value.indexOf("@")+ 1, email.value.length);
    if ((u.length >=1) &&
        (d.length >=3) &&
        (u.search("@")==-1) &&
        (d.search("@")==-1) &&
        (u.search(" ")==-1) &&
        (d.search(" ")==-1) &&
        (d.search(".")!=-1) &&
        (d.indexOf(".") >=1)&&
        (d.lastIndexOf(".") < d.length - 1)) {
            
        labelEmail.setAttribute('style', 'color: red')
        labelEmail.innerHTML = 'Email *Insira o email corretamente'
        email.setAttribute('style', 'border-color: red')
        validEmail = false
    }
    else{
        labelEmail.setAttribute('style', 'color: green')
        labelEmail.innerHTML = 'Email'
        labelEmail.setAttribute('style', 'border-color: green')
    }
        */
    validEmail = true
})


senha.addEventListener('keyup', () => {
  if(senha.value.length <= 5){
    
    validSenha = false
  } else {
    validSenha = true
  }
})

confirmaSenha.addEventListener('keyup', () => {
  if(senha.value != confirmaSenha.value){   
    validConfirmaSenha = false
  } else {
    validConfirmaSenha = true
  }
})

function cadastrar(){
  if(validNome && validEmail && validSenha && validConfirmaSenha){
    let listaUser = JSON.parse(localStorage.getItem('listaUser') || '[]')
    
    listaUser.push(
    {
      nomeCad: nome.value,
      emailCad: email.value,
      cpfCad: cpf.value,
      senhaCad: senha.value
    }
    )
    
    localStorage.setItem('listaUser', JSON.stringify(listaUser))
    
   
    msgSuccess.setAttribute('style', 'display: block')
    msgSuccess.innerHTML = '<strong>Cadastrando usuário...</strong>'
    msgError.setAttribute('style', 'display: none')
    msgError.innerHTML = ''
    
    setTimeout(()=>{
        window.location.href = '../html/login.html'
    }, 3000)
  
    
  } else {
    msgError.setAttribute('style', 'display: block')
    msgError.innerHTML = '<strong>Preencha todos os campos corretamente antes de cadastrar</strong>'
    msgSuccess.innerHTML = ''
    msgSuccess.setAttribute('style', 'display: none')
  }
}

btn.addEventListener('click', ()=>{
  let inputSenha = document.querySelector('#senha')
  
  if(inputSenha.getAttribute('type') == 'password'){
    inputSenha.setAttribute('type', 'text')
  } else {
    inputSenha.setAttribute('type', 'password')
  }
})

btnConfirm.addEventListener('click', ()=>{
  let inputConfirmSenha = document.querySelector('#confirmaSenha')
  
  if(inputConfirmSenha.getAttribute('type') == 'password'){
    inputConfirmSenha.setAttribute('type', 'text')
  } else {
    inputConfirmSenha.setAttribute('type', 'password')
  }
})


//signin

let btn2 = document.querySelector('.fa-eye')

btn.addEventListener('click', ()=>{
  let inputSenha = document.querySelector('#senha')
  
  if(inputSenha.getAttribute('type') == 'password'){
    inputSenha.setAttribute('type', 'text')
  } else {
    inputSenha.setAttribute('type', 'password')
  }
})

function entrar(){
  let email2 = document.querySelector('#emailLogin')
  let emailLabel2 = document.querySelector('#emailLoginLabel')
  
  let senha2 = document.querySelector('#passwordLogin')
  let senhaLabel2 = document.querySelector('#passwordLoginLabel')
  
  let msgError = document.querySelector('#msgError')
  let listaUser = []
  
  let userValid = {
    nome: '',
    email: '',
    senha: ''
  }
  
  listaUser = JSON.parse(localStorage.getItem('listaUser'))
  
  listaUser.forEach((item) => {
    if(email2.value == item.emailCad && senha2.value == item.senhaCad){
       
      userValid = {
         nome: item.nomeCad,
         email: item.emailCad,
         senha: item.senhaCad
       }
      
    }
  })
   
  if(email2.value == userValid.email && senha2.value == userValid.senha || email2.value == 'admin' && senha2.value == 'admin'){
    window.location.href = '/assets/menu.html'
    
    let mathRandom = Math.random().toString(16).substr(2)
    let token = mathRandom + mathRandom
    
    localStorage.setItem('token', token)
    localStorage.setItem('userLogado', JSON.stringify(userValid))
  } else {
    emailLabel2.setAttribute('style', 'color: red')
    email2.setAttribute('style', 'border-color: red')
    senhaLabel2.setAttribute('style', 'color: red')
    senha2.setAttribute('style', 'border-color: red')
    msgError.setAttribute('style', 'display: block')
    msgError.innerHTML = 'Usuário ou senha incorretos'
    email.focus()
  }
  
}





  
  